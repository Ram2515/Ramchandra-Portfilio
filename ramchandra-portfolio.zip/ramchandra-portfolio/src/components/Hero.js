import React from 'react';

const Hero = () => {
  return (
    <section className="hero">
      <h1 className="name">Hello, I'm Ramchandra Hirave</h1>
      <h1>Welcome to My Portfolio</h1>
      <h2 className="typed-text"></h2>
      <a href="#portfolio" className="cta-button">View My Work</a>
    </section>
  );
};

export default Hero;
