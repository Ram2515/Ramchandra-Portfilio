import React, { useState } from 'react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header>
      <div className="container">
        <div className="logo">Ram</div>
        <nav>
          <ul className={`nav-links ${isMenuOpen ? 'open' : ''}`}>
            <li><a href="#about" onClick={toggleMenu}>About</a></li>
            <li><a href="#portfolio" onClick={toggleMenu}>Portfolio</a></li>
            <li><a href="#skills" onClick={toggleMenu}>Skills</a></li>
            <li><a href="#contact" onClick={toggleMenu}>Contact</a></li>
          </ul>
          <div className="burger" onClick={toggleMenu}>
            <div className={isMenuOpen ? 'line open' : 'line'}></div>
            <div className={isMenuOpen ? 'line open' : 'line'}></div>
            <div className={isMenuOpen ? 'line open' : 'line'}></div>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;
