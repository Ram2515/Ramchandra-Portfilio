import React from 'react';

const Skills = () => {
  const skills = [
    { icon: "fab fa-react", name: "ReactJS" },
    { icon: "fab fa-html5", name: "HTML5" },
    { icon: "fab fa-css3-alt", name: "CSS3" },
    { icon: "fab fa-bootstrap", name: "Bootstrap5" },
    { icon: "fab fa-js", name: "JavaScript" },
    { icon: "fab fa-node-js", name: "Node.js" },
    { icon: "fas fa-code", name: "OOP Concepts" },
    { icon: "fas fa-database", name: "JDBC" },
    { icon: "fas fa-java", name: "Core Java" },
    { icon: "fas fa-sync", name: "Redux" },
    { icon: "fab fa-tailwindcss", name: "Tailwind CSS" },
    { icon: "fas fa-mobile-alt", name: "Responsive Web Design" },
    { icon: "fab fa-node-js", name: "Express.js" },
    { icon: "fas fa-database", name: "MongoDB" },
    { icon: "fas fa-globe", name: "RESTful APIs" },
    { icon: "fab fa-java", name: "JSP" },
    { icon: "fas fa-cog", name: "Servlet" },
    { icon: "fas fa-cogs", name: "Maven" },
    { icon: "fas fa-layer-group", name: "Hibernate" },
    { icon: "fas fa-leaf", name: "Spring" },
    { icon: "fas fa-cloud", name: "Spring Boot" },
    { icon: "fab fa-firebase", name: "Firebase" },
    { icon: "fab fa-postman", name: "Postman" },
    { icon: "fas fa-database", name: "MySQL" },
  ];

  return (
    <section id="skills" className="skills">
      <h2>My Skills</h2>
      <div className="skills-container">
        {skills.map((skill, index) => (
          <div className="skill-item" key={index}>
            <i className={skill.icon}></i>
            <h3>{skill.name}</h3>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Skills;
