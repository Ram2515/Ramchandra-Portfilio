import React, { useState } from 'react';

const Portfolio = () => {
  // Sample projects data
  const projects = [
    {
      id: 1,
      title: 'Portfolio Website',
      description: 'A personal portfolio website to showcase my skills and projects.',
      image: 'path/to/portfolio-image.jpg',
      category: 'react',
    },
    {
      id: 2,
      title: 'E-commerce Web App',
      description: 'An online shopping platform built with React and Redux.',
      image: 'path/to/ecommerce-image.jpg',
      category: 'react',
    },
    {
      id: 3,
      title: 'Bookstore (MERN Stack)',
      description: 'A full-stack bookstore application using MongoDB, Express, React, and Node.js.',
      image: 'path/to/bookstore-image.jpg',
      category: 'nodejs',
    },
    {
      id: 4,
      title: 'Amazon Clone',
      description: 'A clone of the Amazon website, built with HTML and CSS.',
      image: 'path/to/amazon-clone-image.jpg',
      category: 'javascript',
    },
  ];

  const [filter, setFilter] = useState('all');

  const handleFilterChange = (category) => {
    setFilter(category);
  };

  const filteredProjects = filter === 'all' 
    ? projects 
    : projects.filter((project) => project.category === filter);

  return (
    <section id="portfolio" className="portfolio">
      <h2>My Projects</h2>
      <div className="filter-buttons">
        <button 
          className={`filter-btn ${filter === 'all' ? 'active' : ''}`} 
          onClick={() => handleFilterChange('all')}
        >
          All
        </button>
        <button 
          className={`filter-btn ${filter === 'react' ? 'active' : ''}`} 
          onClick={() => handleFilterChange('react')}
        >
          React
        </button>
        <button 
          className={`filter-btn ${filter === 'javascript' ? 'active' : ''}`} 
          onClick={() => handleFilterChange('javascript')}
        >
          JavaScript
        </button>
        <button 
          className={`filter-btn ${filter === 'nodejs' ? 'active' : ''}`} 
          onClick={() => handleFilterChange('nodejs')}
        >
          Node-Js
        </button>
      </div>
      <div className="projects-grid">
        {filteredProjects.map((project) => (
          <div key={project.id} className="project-card" data-category={project.category}>
            <img src={project.image} alt={project.title} />
            <h3>{project.title}</h3>
            <p>{project.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Portfolio;
