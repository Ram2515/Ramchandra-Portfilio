import React, { useState, useEffect } from 'react';
import aboutImg from './images/me.jpg'; // Update image path

const About = () => {
  const roles = ['Frontend Developer', 'Software Developer', 'MERN Developer', 'Full Stack Developer'];
  const [currentRoleIndex, setCurrentRoleIndex] = useState(0);

  const changeRole = () => {
    setCurrentRoleIndex((prevIndex) => (prevIndex + 1) % roles.length);
  };

  useEffect(() => {
    const interval = setInterval(changeRole, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section id="about" className="about">
      <h2>About Me</h2>
      <div className="about-content">
        <div className="about-image">
          <img src={aboutImg} alt="About Me" />
        </div>
        <div className="about-text">
          <h2>
            Hello! I’m Ramchandra Hirave, a passionate <span className="role">{roles[currentRoleIndex]}</span>...
          </h2>
        </div>
      </div>
    </section>
  );
};

export default About;
